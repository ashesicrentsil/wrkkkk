import pandas as pd 

df = pd.read_csv(r'C:\Users\asus\Desktop\P.F.E\data\data.csv')
print(df.describe())

print(df.isnull().sum())
df.dropna()

print(df.duplicated())
df.drop_duplicates(inplace=True)

print(df['alcohol'].describe())
print(df['ID'].describe())

import matplotlib.pyplot as plt

fig, ax = plt.subplots(figsize=(10,5))
ax.hist(df['alcohol'], bins = 20, rwidth = 0.8)
ax.set_xlabel('ALCOHOL')
ax.set_ylabel('FREQUENCY')
ax.set_title('HISTOGRAM')

fig, ax = plt.subplots(figsize=(10,5))
ax.boxplot(df['alcohol'])

corr = df.corr()
sns.heatmap(corr, annot=False, cmap='warmcool')

