# class Person:
#     def __init__(self, firstName, lastNmae, age):
#         self.firstName = firstName
#         self.lastNmae = lastNmae
#         self. age =  age
#         self.email = f'{firstName[0]}.{lastNmae}@st.ug.edu.gh'.lower()

#     def fullName(self):
#         return f'{self.firstName} {self.lastNmae}'
#     def name_initials(self):
#         return f'{self.firstName[0]}.{self.lastNmae[0]}'
    
# class Student(Person):
#     def __init__(self, firstName, lastNmae, age, hall_of_residence, courses=None):
#         super().__init__(firstName, lastNmae, age)
#         self.hall_of_residence = hall_of_residence
#         if courses is None:
#             self.courses = []
#         else:
#             self.courses = courses

#     def add_course(self, course_title):
#         if course_title not in self.courses:
#             self.courses.append(course_title)

#     def drop_course(self, course_title):
#         if course_title in self.courses:
#             self.courses.remove(course_title)

#     def print_all_courses(self):
#         return f'{self.fullName()} registered {len(self.courses)} courses'



# Student1 = Student('Ashesi', 'Crentsil', 19,'LIMANN HALL')
# print(Student1.fullName())
# print(Student1.name_initials())
# print(Student1.email)

# Student1.add_course('PHYSICS')
# Student1.add_course('MATHS')
# Student1.add_course('SOCIAL')
# Student1.add_course('CHEMISTRY')
# Student1.add_course('FRENCH')

# print(Student1.print_all_courses())
# print(Student1.courses)
# 2
2
num = int(input("Enter a number: "))
factorial = 1

if num < 0:
    print("Factorial does not exist for negative numbers.")
elif num == 0:
    print("The factorial of 0 is 1.")
else:
    for i in range(1, num + 1):
        factorial *= i

    print("The factorial of", num, "is", factorial)