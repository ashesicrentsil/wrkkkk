//QUESTION 3
#include <iostream>




using namespace std;


//a function called power() that takes a double value for n and an int value for p, and
//returns the result as a double value. Use a default argument of 2 for p, so that if
//this argument is omitted, the number n will be squared.
double power(double n,int p=2){
	double result=1;
	for(int i=0;i<p;i++){
		result*=n;
	}
	return result;
}


int main (){
	double n;
	int p;
	double result=0;
	//Write a main() function that gets values from the user to test this function.
	cout<<"Enter n: ";
	cin>>n;
	cout<<"Enter p: ";
	cin>>p;
	if(p<0){
		result=power(n);
		cout<<n<<"^2 = "<<result<<"\n\n";
	}else{
		result=power(n,p);
		cout<<n<<"^"<<p<<" = "<<result<<"\n\n";
	}



	system("pause");
	return 0;
}

