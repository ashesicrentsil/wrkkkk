import React, { useState } from 'react';
import './App.css';

const App = () => {
  const [studentId, setStudentId] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    console.log('Logging in...');
    console.log('Student ID:', studentId);
    console.log('Password:', password);
    // Add your login logic here
  };

  const handleForgotPassword = () => {
    console.log('Forgot password...');
    // Add your forgot password logic here
  };

  return (
    <div className="App">
      <h2>Student Login</h2>
      <form>
        <div>
          <label htmlFor="studentId">Student ID:</label>
          <input
            type="text"
            id="studentId"
            value={studentId}
            onChange={(e) => setStudentId(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        <div>
          <button type="button" onClick={handleLogin}>Login</button>
          <button type="button" onClick={handleForgotPassword}>Forgot Password</button>
        </div>
      </form>
    </div>
  );
};

export default App;
