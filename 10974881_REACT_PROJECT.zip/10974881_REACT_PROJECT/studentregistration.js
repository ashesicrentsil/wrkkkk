import React, { useState } from 'react';

const StudentRegistration = () => {
  const [name, setName] = useState('');
  const [id, setId] = useState('');
  const [email, setEmail] = useState('');
  const [level, setLevel] = useState('');
  const [programOffering, setProgramOffering] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Student Information:', { name, id, email, level, programOffering });
    // You can add further logic to handle the form submission, such as sending data to a server or updating the database.
    // Reset the form fields
    setName('');
    setId('');
    setEmail('');
    setLevel('');
    setProgramOffering('');
  };

  return (
    <div>
      <h2>Student Registration</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Name:</label>
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <label>ID:</label>
          <input type="text" value={id} onChange={(e) => setId(e.target.value)} />
        </div>
        <div>
          <label>Email:</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div>
          <label>Level:</label>
          <input type="text" value={level} onChange={(e) => setLevel(e.target.value)} />
        </div>
        <div>
          <label>Program Offering:</label>
          <input type="text" value={programOffering} onChange={(e) => setProgramOffering(e.target.value)} />
        </div>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default StudentRegistration;
